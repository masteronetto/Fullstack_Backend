Write-Host 'Iniciando Spring Boot Server...' -ForegroundColor Green
Set-Location 'c:\Users\onett\OneDrive\Escritorio\proyectokebumyspringbootbackend'
& '.\mvnw.cmd' 'spring-boot:run'
