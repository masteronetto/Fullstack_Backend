package com.danny.proyectokebumyspringbootbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectokebumyspringbootbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
