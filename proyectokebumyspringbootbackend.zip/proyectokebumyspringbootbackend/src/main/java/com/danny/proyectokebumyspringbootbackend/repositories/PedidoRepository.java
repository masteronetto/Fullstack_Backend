package com.danny.proyectokebumyspringbootbackend.repositories;

import com.danny.proyectokebumyspringbootbackend.entities.Pedido;
import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> findByUsuarioOrderByFechaPedidoDesc(Usuario usuario);
    List<Pedido> findByUsuarioIdOrderByFechaPedidoDesc(Long usuarioId);
    List<Pedido> findByUsuario_IdOrderByFechaPedidoDesc(Long usuarioId);
    List<Pedido> findByEstadoPedido(String estadoPedido);
    List<Pedido> findByEstadoPedidoOrderByFechaPedidoDesc(String estadoPedido);
    List<Pedido> findAllByOrderByFechaPedidoDesc();
    Optional<Pedido> findByNumeroPedido(String numeroPedido);
    Optional<Pedido> findByStripeCheckoutSessionId(String sessionId);
    Optional<Pedido> findByStripePaymentIntentId(String paymentIntentId);
}
