package com.danny.proyectokebumyspringbootbackend.config;

import com.danny.proyectokebumyspringbootbackend.entities.Producto;
import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import com.danny.proyectokebumyspringbootbackend.repositories.ProductoRepository;
import com.danny.proyectokebumyspringbootbackend.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private ProductoRepository productoRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Verificación optimizada: una sola query para usuarios
        long countUsuarios = usuarioRepository.count();
        if (countUsuarios == 0) {
            System.out.println("=== INICIALIZANDO DATOS DE USUARIOS ===");
            inicializarUsuarios();
            System.out.println("=== USUARIOS INICIALIZADOS: " + usuarioRepository.count() + " usuarios ===");
        } else {
            System.out.println("=== BASE DE DATOS YA CONTIENE USUARIOS (" + countUsuarios + ") - OMITIENDO INICIALIZACIÓN ===");
        }
        
        // Verificación optimizada: una sola query para productos
        long countProductos = productoRepository.count();
        if (countProductos == 0) {
            System.out.println("=== INICIALIZANDO DATOS DE PRODUCTOS ===");
            inicializarProductos();
            System.out.println("=== PRODUCTOS INICIALIZADOS: " + productoRepository.count() + " productos ===");
        } else {
            System.out.println("=== BASE DE DATOS YA CONTIENE PRODUCTOS (" + countProductos + ") - OMITIENDO INICIALIZACIÓN ===");
        }
    }
    
    private void inicializarUsuarios() {
        // Usuario Admin
        crearUsuario("Admin Kebumy", "admin@kebumy.com", "admin123");
        
        // Usuarios de prueba
        crearUsuario("Ana Torres", "ana.torres@cliente.com", "cliente123");
        crearUsuario("Carlos López", "carlos.lopez@cliente.com", "cliente123");
        crearUsuario("María González", "maria.gonzalez@cliente.com", "cliente123");
    }
    
    private void crearUsuario(String nombre, String email, String password) {
        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setEmail(email);
        usuario.setPassword(passwordEncoder.encode(password));
        usuario.setFechaCreacion(LocalDateTime.now());
        
        // Asignar rol según email
        if (email.equals("admin@kebumy.com")) {
            usuario.setRol("admin");
            usuario.setTipoUsuario("admin");
        } else {
            usuario.setRol("cliente");
            usuario.setTipoUsuario("cliente");
        }
        
        usuarioRepository.save(usuario);
        System.out.println("✅ Usuario creado: " + email + " (rol: " + usuario.getRol() + ")");
    }

    private void inicializarProductos() {
        // Para ti
        crearProducto("Poleras con Diseños", 
            "Poleras personalizadas con diseños únicos y originales.", 
            "Poleras personalizadas", 
            new BigDecimal("15990"), 8, "para-ti", "Para ti", 
            "img/Polera.png", "Sí");

        crearProducto("Polerones Exclusivos", 
            "Polerones con diseños exclusivos y felpa de alta calidad.", 
            "Polerones con felpa", 
            new BigDecimal("25000"), 3, "para-ti", "Para ti", 
            "img/Poleron.png", "Sí");

        crearProducto("Libretas A5 Classic", 
            "Libretas de formato A5 de alta calidad para tus notas.", 
            "Libretas A5", 
            new BigDecimal("5200"), 12, "para-ti", "Para ti", 
            "img/Agenda.png", "Sí");

        crearProducto("Stickers Vinilo Pack", 
            "Pack de stickers de vinilo personalizados resistentes.", 
            "Pack de stickers", 
            new BigDecimal("3800"), 50, "para-ti", "Para ti", 
            "img/sticker.png", "Sí");

        crearProducto("Fotografías Polaroid", 
            "Impresiones de fotografías estilo Polaroid retro.", 
            "Fotos Polaroid", 
            new BigDecimal("2500"), 10, "para-ti", "Para ti", 
            "img/Polaroid.png", "No");

        // Para marcas
        crearProducto("Calendarios Imantados", 
            "Calendarios personalizados imantados para empresas.", 
            "Calendarios empresariales", 
            new BigDecimal("5000"), 30, "para-marcas", "Para marcas", 
            "img/miniCalendario.png", "Sí");

        crearProducto("Poleras de Empresa Logo", 
            "Poleras corporativas para tu equipo de trabajo o eventos.", 
            "Poleras corporativas", 
            new BigDecimal("12000"), 40, "para-marcas", "Para marcas", 
            "img/PolerasMarca.png", "Sí");

        crearProducto("Tarjetas Presentación", 
            "Tarjetas de presentación profesionales de alta calidad.", 
            "Tarjetas profesionales", 
            new BigDecimal("6000"), 60, "para-marcas", "Para marcas", 
            "img/tarjetaPresentacion.png", "Sí");

        crearProducto("Etiquetas para Ropa Cuero", 
            "Etiquetas de cuero premium para vestuario de marca.", 
            "Etiquetas de cuero", 
            new BigDecimal("300"), 200, "para-marcas", "Para marcas", 
            "img/etiquetaCuero.png", "Sí");

        crearProducto("Stickers de Marca Logo", 
            "Stickers de vinilo personalizados para empaques y productos.", 
            "Stickers corporativos", 
            new BigDecimal("3500"), 150, "para-marcas", "Para marcas", 
            "img/stickerMarca.png", "Sí");

        crearProducto("Mochila Personalizada", 
            "Mochilas de alta calidad personalizadas para eventos o regalos corporativos.", 
            "Mochilas corporativas", 
            new BigDecimal("18000"), 25, "para-marcas", "Para marcas", 
            "img/Mochila.png", "Sí");
    }

    private void crearProducto(String nombre, String descripcion, String descripcionCorta, 
                               BigDecimal precio, int stock, String categoria, String categoriaNombre,
                               String imagenUrl, String personalizable) {
        Producto producto = new Producto();
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setDescripcionCorta(descripcionCorta);
        producto.setPrecio(precio);
        producto.setStock(stock);
        producto.setStockDisponible(stock);
        producto.setStockMinimo(stock < 10 ? 1 : 10);
        producto.setCategoria(categoria);
        producto.setCategoriaNombre(categoriaNombre);
        producto.setImagenUrl(imagenUrl);
        producto.setImagenPrincipal(imagenUrl);
        producto.setPersonalizable(personalizable);
        producto.setEstado("activo");
        producto.setFechaCreacion(LocalDateTime.now());
        
        productoRepository.save(producto);
    }
}
