package com.danny.proyectokebumyspringbootbackend.security;

import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class RoleResolver {

    // Lista de emails que son administradores
    private static final List<String> ADMIN_EMAILS = Arrays.asList(
            "admin@kebumy.com",
            "administrador@kebumy.com",
            "superadmin@kebumy.com"
    );

    // Lista de dominios de administradores
    private static final List<String> ADMIN_DOMAINS = Arrays.asList(
            "@admin.kebumy.com",
            "@staff.kebumy.com"
    );

    /**
     * Determina automáticamente el rol basado en el email
     * @param email Email del usuario
     * @return "admin" si es administrador, "cliente" si es usuario normal
     */
    public String determineRol(String email) {
        if (email == null || email.trim().isEmpty()) {
            return "cliente";
        }

        String emailLower = email.toLowerCase().trim();

        // Verificar si está en la lista de emails admin
        if (ADMIN_EMAILS.contains(emailLower)) {
            return "admin";
        }

        // Verificar si el dominio es de admin
        for (String domain : ADMIN_DOMAINS) {
            if (emailLower.endsWith(domain)) {
                return "admin";
            }
        }

        // Verificar si el email contiene "admin" antes del @
        String[] parts = emailLower.split("@");
        if (parts.length > 0 && parts[0].contains("admin")) {
            return "admin";
        }

        // Por defecto es cliente
        return "cliente";
    }

    /**
     * Determina el tipo_usuario basado en el rol
     * @param rol Rol del usuario ("admin" o "cliente")
     * @return "administrador" si rol es "admin", "usuario" si es "cliente"
     */
    public String determineTipoUsuario(String rol) {
        if (rol == null) {
            return "usuario";
        }
        
        return rol.equals("admin") ? "administrador" : "usuario";
    }

    /**
     * Sincroniza rol y tipo_usuario
     * @param email Email del usuario
     * @return Array con [rol, tipo_usuario]
     */
    public String[] syncRoleAndType(String email) {
        String rol = determineRol(email);
        String tipoUsuario = determineTipoUsuario(rol);
        return new String[]{rol, tipoUsuario};
    }
}
