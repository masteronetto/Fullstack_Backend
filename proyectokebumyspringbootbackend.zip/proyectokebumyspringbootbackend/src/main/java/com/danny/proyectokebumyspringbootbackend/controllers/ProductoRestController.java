package com.danny.proyectokebumyspringbootbackend.controllers;
import com.danny.proyectokebumyspringbootbackend.entities.Producto;
import com.danny.proyectokebumyspringbootbackend.services.ProductoService;
import com.danny.proyectokebumyspringbootbackend.security.RequiresAdmin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = {"http://localhost:5173"})
public class ProductoRestController {
     @Autowired
    private ProductoService productoService;

    
    @RequiresAdmin
    @PostMapping
    public ResponseEntity<?> crearProducto(@RequestBody Producto producto) {
        try {
            Producto nuevoProducto = productoService.crear(producto);
            return new ResponseEntity<>(nuevoProducto, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> listarProductos(@RequestParam(required = false) String categoria) {
        try {
            System.out.println("=== LISTAR PRODUCTOS ===");
            System.out.println("Filtro categoria: " + categoria);
            
            List<Producto> productos = productoService.listarTodas();
            
            // Filtrar por categoría si se especifica
            if (categoria != null && !categoria.trim().isEmpty()) {
                productos = productos.stream()
                    .filter(p -> categoria.equalsIgnoreCase(p.getCategoria()) || 
                               categoria.equalsIgnoreCase(p.getCategoriaNombre()))
                    .collect(java.util.stream.Collectors.toList());
                System.out.println("Productos filtrados por categoría '" + categoria + "': " + productos.size());
            }
            
            System.out.println("Productos encontrados: " + productos.size());
            
            // Formatear respuesta compatible con frontend BDD
            List<Map<String, Object>> productosBDD = productos.stream().map(p -> {
                Map<String, Object> productoBDD = new HashMap<>();
                productoBDD.put("id", p.getId());
                productoBDD.put("id_producto", p.getId()); // Alias para BDD
                productoBDD.put("nombre", p.getNombre());
                productoBDD.put("descripcion", p.getDescripcion());
                productoBDD.put("descripcionCorta", p.getDescripcionCorta());
                productoBDD.put("categoria", p.getCategoria());
                productoBDD.put("personalizable", p.getPersonalizable());
                productoBDD.put("imagenPrincipal", p.getImagenPrincipal());
                productoBDD.put("precio", p.getPrecio());
                productoBDD.put("stock", p.getStock());
                productoBDD.put("stockDisponible", p.getStockDisponible());
                productoBDD.put("stockMinimo", p.getStockMinimo());
                return productoBDD;
            }).collect(java.util.stream.Collectors.toList());
            
            Map<String, Object> response = new HashMap<>();
            response.put("productos", productosBDD);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.out.println("Error al listar productos: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    @GetMapping("/catalogo")
    public ResponseEntity<?> obtenerCatalogo(@RequestParam(required = false) String categoria) {
        try {
            System.out.println("=== OBTENER CATÁLOGO ===");
            System.out.println("Filtro categoria: " + categoria);
            
            List<Producto> productos = productoService.listarTodas();
            
            // Filtrar por categoría si se especifica
            if (categoria != null && !categoria.trim().isEmpty()) {
                productos = productos.stream()
                    .filter(p -> categoria.equalsIgnoreCase(p.getCategoria()) || 
                               categoria.equalsIgnoreCase(p.getCategoriaNombre()))
                    .collect(java.util.stream.Collectors.toList());
            }
            
            System.out.println("Productos en catálogo: " + productos.size());
            
            // Formatear respuesta para frontend
            List<Map<String, Object>> productosCatalogo = productos.stream().map(p -> {
                Map<String, Object> producto = new HashMap<>();
                producto.put("id", p.getId());
                producto.put("id_producto", p.getId());
                producto.put("nombre", p.getNombre());
                producto.put("descripcion", p.getDescripcion());
                producto.put("descripcion_corta", p.getDescripcionCorta());
                producto.put("categoria", p.getCategoria());
                producto.put("categoria_nombre", p.getCategoriaNombre());
                producto.put("personalizable", p.getPersonalizable());
                producto.put("imagen_url", p.getImagenUrl());
                producto.put("imagen_principal", p.getImagenPrincipal());
                producto.put("precio", p.getPrecio());
                producto.put("stock", p.getStock());
                producto.put("stock_disponible", p.getStockDisponible());
                producto.put("stock_minimo", p.getStockMinimo());
                producto.put("estado", p.getEstado());
                return producto;
            }).collect(java.util.stream.Collectors.toList());
            
            return ResponseEntity.ok(productosCatalogo);
        } catch (Exception e) {
            System.out.println("Error al obtener catálogo: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    @GetMapping("/categorias")
    public ResponseEntity<?> obtenerCategorias() {
        try {
            System.out.println("=== OBTENER CATEGORÍAS ===");
            
            List<Producto> productos = productoService.listarTodas();
            
            // Extraer categorías únicas
            List<String> categorias = productos.stream()
                .map(Producto::getCategoria)
                .distinct()
                .filter(c -> c != null && !c.trim().isEmpty())
                .sorted()
                .collect(java.util.stream.Collectors.toList());
            
            System.out.println("Categorías encontradas: " + categorias.size());
            
            return ResponseEntity.ok(categorias);
        } catch (Exception e) {
            System.out.println("Error al obtener categorías: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    
    
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerProductoPorId(@PathVariable Long id) {
        try {
            Producto producto = productoService.obtenerId(id);
            return ResponseEntity.ok(producto);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    
    @RequiresAdmin
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProducto(@PathVariable Long id, @RequestBody Producto productoActualizado) {
        try {
            Producto producto = productoService.actualizar(id, productoActualizado);
            return ResponseEntity.ok(producto);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    
    @RequiresAdmin
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable Long id) {
        try {
            productoService.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
    
    
    @GetMapping("/stock-bajo")
    public ResponseEntity<List<Producto>> obtenerStockBajo() {
      
        List<Producto> productos = productoService.obtenerProductosStockBajo(5);
        return ResponseEntity.ok(productos);
    }
    
    @GetMapping("/test")
    public ResponseEntity<?> testConexion() {
        try {
            System.out.println("=== TEST DE CONEXIÓN ===");
            List<Producto> productos = productoService.listarTodas();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Conexión exitosa");
            response.put("count", productos.size());
            response.put("productos", productos);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.out.println("Error en test de conexión: " + e.getMessage());
            e.printStackTrace();
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error de conexión");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
