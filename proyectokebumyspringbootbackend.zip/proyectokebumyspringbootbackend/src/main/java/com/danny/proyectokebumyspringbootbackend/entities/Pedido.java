package com.danny.proyectokebumyspringbootbackend.entities;

import jakarta.persistence.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    @JsonIgnoreProperties({"password", "carrito", "pedidos"})
    private Usuario usuario;
    
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("pedido-items")
    private List<ItemPedido> items = new ArrayList<>();
    
    @Column(name = "numero_pedido", unique = true)
    private String numeroPedido; // ORD-20250117-001
    
    private BigDecimal subtotal;
    private BigDecimal envio;
    private BigDecimal descuento = BigDecimal.ZERO;
    private BigDecimal total;
    private BigDecimal iva = BigDecimal.ZERO;
    
    @Column(name = "metodo_pago")
    private String metodoPago; // stripe, transferencia, efectivo
    
    @Column(name = "estado_pago")
    private String estadoPago = "pendiente"; // pendiente, pagado, fallido, reembolsado
    
    @Column(name = "estado_pedido")
    private String estadoPedido = "procesando"; // procesando, preparando, enviado, entregado, cancelado
    
    @Column(name = "stripe_payment_intent_id")
    private String stripePaymentIntentId;
    
    @Column(name = "stripe_checkout_session_id")
    private String stripeCheckoutSessionId;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "fecha_pedido")
    private LocalDateTime fechaPedido;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "fecha_pago")
    private LocalDateTime fechaPago;
    
    // Datos de envío
    @Column(name = "direccion_envio")
    private String direccionEnvio;
    
    @Column(name = "ciudad")
    private String ciudad;
    
    @Column(name = "region")
    private String region;
    
    @Column(name = "codigo_postal")
    private String codigoPostal;
    
    @Column(name = "telefono_contacto")
    private String telefonoContacto;
    
    @Column(name = "notas")
    private String notas;
    
    @PrePersist
    protected void onCreate() {
        fechaPedido = LocalDateTime.now();
        if (numeroPedido == null) {
            generarNumeroPedido();
        }
    }
    
    private void generarNumeroPedido() {
        // Formato: ORD-YYYYMMDD-XXX
        String fecha = LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String random = String.format("%03d", (int)(Math.random() * 1000));
        numeroPedido = "ORD-" + fecha + "-" + random;
    }


    @JsonProperty("iva")
    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }
}
