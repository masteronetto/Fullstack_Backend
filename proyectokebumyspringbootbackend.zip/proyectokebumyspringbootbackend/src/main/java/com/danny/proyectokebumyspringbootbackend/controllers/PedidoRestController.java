package com.danny.proyectokebumyspringbootbackend.controllers;

import com.danny.proyectokebumyspringbootbackend.entities.Pedido;
import com.danny.proyectokebumyspringbootbackend.services.PedidoService;
import com.danny.proyectokebumyspringbootbackend.services.PedidoService.DatosEnvioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pedidos")
@CrossOrigin(origins = "*")
public class PedidoRestController {
    
    @Autowired
    private PedidoService pedidoService;
    
    /**
     * Crear pedido desde carrito (simulado - sin Stripe)
     * POST /api/pedidos/crear
     */
    @PostMapping("/crear")
    public ResponseEntity<?> crearPedido(@RequestBody Map<String, Object> request) {
        try {
            Long usuarioId = Long.valueOf(request.get("usuarioId").toString());
            
            // Parsear datos de envío
            @SuppressWarnings("unchecked")
            Map<String, String> datosEnvioMap = (Map<String, String>) request.get("datosEnvio");
            
            DatosEnvioDTO datosEnvio = new DatosEnvioDTO();
            datosEnvio.setDireccion(datosEnvioMap.get("direccion"));
            datosEnvio.setCiudad(datosEnvioMap.get("ciudad"));
            datosEnvio.setRegion(datosEnvioMap.get("region"));
            datosEnvio.setCodigoPostal(datosEnvioMap.get("codigoPostal"));
            datosEnvio.setTelefono(datosEnvioMap.get("telefono"));
            datosEnvio.setNotas(datosEnvioMap.get("notas"));
            
            // Crear pedido sin Stripe (simulado)
            Pedido pedido = pedidoService.crearPedidoSimulado(usuarioId, datosEnvio);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Pedido creado exitosamente",
                "pedido", pedido,
                "checkoutUrl", "/checkout/" + pedido.getId()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Procesar pago simulado
     * POST /api/pedidos/{pedidoId}/pagar
     */
    @PostMapping("/{pedidoId}/pagar")
    public ResponseEntity<?> procesarPago(
            @PathVariable Long pedidoId,
            @RequestBody Map<String, String> request) {
        try {
            String metodoPago = request.get("metodoPago"); // tarjeta, paypal, webpay
            
            Pedido pedido = pedidoService.procesarPagoSimulado(pedidoId, metodoPago);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Pago procesado exitosamente",
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Confirmar pago después del éxito (ya no usado - payment simulado)
     * POST /api/pedidos/confirmar-pago
     */
    @PostMapping("/confirmar-pago")
    public ResponseEntity<?> confirmarPago(@RequestBody Map<String, String> request) {
        try {
            String sessionId = request.get("sessionId");
            // Ya no se usa - pago simulado
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Endpoint obsoleto - usar /pagar"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Obtener pedidos de un usuario
     * GET /api/pedidos/usuario/{usuarioId}
     */
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> obtenerPedidosUsuario(@PathVariable Long usuarioId) {
        try {
            List<Pedido> pedidos = pedidoService.obtenerPedidosUsuario(usuarioId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "pedidos", pedidos
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Obtener pedido por número
     * GET /api/pedidos/numero/{numeroPedido}
     */
    @GetMapping("/numero/{numeroPedido}")
    public ResponseEntity<?> obtenerPedidoPorNumero(@PathVariable String numeroPedido) {
        try {
            Pedido pedido = pedidoService.obtenerPedidoPorNumero(numeroPedido);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Obtener pedido por ID
     * GET /api/pedidos/{pedidoId}
     */
    @GetMapping("/{pedidoId}")
    public ResponseEntity<?> obtenerPedido(@PathVariable Long pedidoId) {
        try {
            Pedido pedido = pedidoService.obtenerPedidoPorId(pedidoId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Actualizar estado del pedido (solo admin)
     * PUT /api/pedidos/{pedidoId}/estado
     */
    @PutMapping("/{pedidoId}/estado")
    public ResponseEntity<?> actualizarEstado(
            @PathVariable Long pedidoId,
            @RequestBody Map<String, String> request) {
        try {
            String nuevoEstado = request.get("estado");
            Pedido pedido = pedidoService.actualizarEstadoPedido(pedidoId, nuevoEstado);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Estado actualizado",
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Confirmar pedido (solo admin)
     * POST /api/pedidos/{pedidoId}/confirmar
     */
    @PostMapping("/{pedidoId}/confirmar")
    public ResponseEntity<?> confirmarPedido(@PathVariable Long pedidoId) {
        try {
            Pedido pedido = pedidoService.actualizarEstadoPedido(pedidoId, "confirmado");
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Pedido confirmado",
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Cancelar pedido (admin o usuario)
     * POST /api/pedidos/{pedidoId}/cancelar
     */
    @PostMapping("/{pedidoId}/cancelar")
    public ResponseEntity<?> cancelarPedido(@PathVariable Long pedidoId) {
        try {
            Pedido pedido = pedidoService.actualizarEstadoPedido(pedidoId, "cancelado");
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Pedido cancelado",
                "pedido", pedido
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Obtener todos los pedidos pendientes (solo admin)
     * GET /api/pedidos/pendientes
     */
    @GetMapping("/pendientes")
    public ResponseEntity<?> obtenerPedidosPendientes() {
        try {
            List<Pedido> pedidos = pedidoService.obtenerPedidosPorEstado("pendiente");
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "pedidos", pedidos
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Obtener todos los pedidos (solo admin)
     * GET /api/pedidos/todos
     * GET /api/pedidos/todos?estado=pendiente
     */
    @GetMapping("/todos")
    public ResponseEntity<?> obtenerTodosPedidos(@RequestParam(required = false) String estado) {
        try {
            List<Pedido> pedidos;
            
            if (estado != null && !estado.isEmpty()) {
                // Filtrar por estado
                pedidos = pedidoService.obtenerPedidosPorEstado(estado);
            } else {
                // Obtener todos
                pedidos = pedidoService.obtenerTodosPedidos();
            }
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "pedidos", pedidos,
                "total", pedidos.size()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}
