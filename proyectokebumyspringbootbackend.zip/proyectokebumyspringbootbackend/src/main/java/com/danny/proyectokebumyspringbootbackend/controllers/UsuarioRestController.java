package com.danny.proyectokebumyspringbootbackend.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import com.danny.proyectokebumyspringbootbackend.services.UsuarioService;
import com.danny.proyectokebumyspringbootbackend.security.JwtService;
import com.danny.proyectokebumyspringbootbackend.security.RequiresAuth;
import com.danny.proyectokebumyspringbootbackend.security.RequiresAdmin;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = {"http://localhost:5173"})
public class UsuarioRestController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private JwtService jwtService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credenciales) {
        try {
            System.out.println("=== LOGIN ATTEMPT ===");
            System.out.println("Credenciales recibidas: " + credenciales);

            String email = credenciales.get("email");
            String password = credenciales.get("password");

            if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Email y contraseña son requeridos");
                response.put("error", "Credenciales incompletas");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }

            Usuario usuarioAutenticado = usuarioService.validarCredenciales(email, password);
            System.out.println("Usuario encontrado: " + (usuarioAutenticado != null));

            if (usuarioAutenticado != null) {
                // Generar token JWT
                String token = jwtService.generateToken(
                    usuarioAutenticado.getEmail(),
                    usuarioAutenticado.getId(),
                    usuarioAutenticado.getRol(),
                    usuarioAutenticado.getTipoUsuario()
                );
                
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Login exitoso");
                response.put("token", token);
                
                // Estructura de usuario compatible con frontend
                Map<String, Object> usuario = new HashMap<>();
                usuario.put("id", usuarioAutenticado.getId());
                usuario.put("id_usuario", usuarioAutenticado.getId());
                usuario.put("nombre", usuarioAutenticado.getNombre());
                usuario.put("email", usuarioAutenticado.getEmail());
                usuario.put("rol", usuarioAutenticado.getRol());
                usuario.put("tipo_usuario", usuarioAutenticado.getTipoUsuario());
                
                response.put("usuario", usuario);
                
                System.out.println("Login exitoso para: " + usuarioAutenticado.getNombre() + " - Rol: " + usuarioAutenticado.getRol());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Credenciales inválidas");
                response.put("error", "Usuario o contraseña incorrectos");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } catch (Exception e) {
            System.out.println("Error en login: " + e.getMessage());
            e.printStackTrace();
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error interno del servidor");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        try {
            System.out.println("=== REGISTRO ATTEMPT ===");
            System.out.println("Usuario recibido: " + usuario);

            // El rol y tipo_usuario se asignan automáticamente en el servicio
            Usuario nuevoUsuario = usuarioService.crear(usuario);

            // Generar token JWT para login automático
            String token = jwtService.generateToken(
                nuevoUsuario.getEmail(),
                nuevoUsuario.getId(),
                nuevoUsuario.getRol(),
                nuevoUsuario.getTipoUsuario()
            );

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario registrado exitosamente");
            response.put("token", token);
            
            // Respuesta compatible con frontend
            Map<String, Object> usuarioBDD = new HashMap<>();
            usuarioBDD.put("id", nuevoUsuario.getId());
            usuarioBDD.put("id_usuario", nuevoUsuario.getId());
            usuarioBDD.put("nombre", nuevoUsuario.getNombre());
            usuarioBDD.put("email", nuevoUsuario.getEmail());
            usuarioBDD.put("rol", nuevoUsuario.getRol());
            usuarioBDD.put("tipo_usuario", nuevoUsuario.getTipoUsuario());
            
            response.put("usuario", usuarioBDD);

            System.out.println("Usuario creado exitosamente: " + nuevoUsuario.getEmail() + " - Rol: " + nuevoUsuario.getRol());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error en registro: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @RequiresAdmin
    @GetMapping
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        try {
            System.out.println("=== LISTAR USUARIOS ===");
            List<Usuario> usuarios = usuarioService.listarTodas();
            usuarios.forEach(u -> u.setPassword(null));
            return ResponseEntity.ok(usuarios);
        } catch (Exception e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/total")
    public ResponseEntity<?> obtenerTotalUsuarios() {
        try {
            System.out.println("=== OBTENER TOTAL USUARIOS ===");
            List<Usuario> usuarios = usuarioService.listarTodas();
            
            Map<String, Object> response = new HashMap<>();
            response.put("total", usuarios.size());
            
            System.out.println("Total de usuarios: " + usuarios.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.out.println("Error al obtener total de usuarios: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("error", "Error al obtener total de usuarios");
            response.put("details", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @RequiresAuth
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.obtenerId(id);
            usuario.setPassword(null);
            return ResponseEntity.ok(usuario);
        } catch (RuntimeException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", "Usuario no encontrado");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @RequiresAdmin
    @PostMapping("/admin")
    public ResponseEntity<?> crearUsuarioAdmin(@RequestBody Usuario usuario) {
        try {
            System.out.println("=== CREAR USUARIO (ADMIN) ===");
            System.out.println("Usuario recibido: " + usuario);

            Usuario nuevoUsuario = usuarioService.crear(usuario);
            nuevoUsuario.setPassword(null);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario creado exitosamente");
            response.put("usuario", nuevoUsuario);

            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            System.out.println("Error al crear usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @RequiresAuth
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuarioActualizado) {
        try {
            System.out.println("=== ACTUALIZAR USUARIO ===");
            System.out.println("ID: " + id + ", Usuario: " + usuarioActualizado);

            Usuario usuario = usuarioService.actualizar(id, usuarioActualizado);
            usuario.setPassword(null);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario actualizado exitosamente");
            response.put("usuario", usuario);

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error al actualizar usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @RequiresAdmin
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        try {
            System.out.println("=== ELIMINAR USUARIO ===");
            System.out.println("ID a eliminar: " + id);

            usuarioService.eliminar(id);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Usuario eliminado exitosamente");

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
}
