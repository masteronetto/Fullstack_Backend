package com.danny.proyectokebumyspringbootbackend.services;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import com.danny.proyectokebumyspringbootbackend.entities.Pedido;
import com.danny.proyectokebumyspringbootbackend.entities.ItemPedido;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class StripeService {
    
    @Value("${stripe.secret.key:sk_test_51QRDtQH4q7kxWv6L9IEgOQhWXM1RN7T7BxCtESlRKV8jg1gL4SdyZQ2RJGpI5F9jLF8fWpJgUJbh8y5uNXcXd5zA00K8VYl0rX}")
    private String stripeSecretKey;
    
    @Value("${stripe.webhook.secret:}")
    private String webhookSecret;
    
    @Value("${frontend.url:http://localhost:5173}")
    private String frontendUrl;
    
    @PostConstruct
    public void init() {
        Stripe.apiKey = stripeSecretKey;
    }
    
    /**
     * Crear sesión de pago con Stripe Checkout
     */
    public Session crearSesionPago(Pedido pedido) throws StripeException {
        List<SessionCreateParams.LineItem> lineItems = new ArrayList<>();
        
        // Agregar items del pedido
        for (ItemPedido item : pedido.getItems()) {
            SessionCreateParams.LineItem lineItem = SessionCreateParams.LineItem.builder()
                .setPriceData(
                    SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency("clp")
                        .setUnitAmount(convertirACentavos(item.getPrecioUnitario()))
                        .setProductData(
                            SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                .setName(item.getNombreProducto())
                                .setDescription(item.getProducto() != null ? 
                                    item.getProducto().getDescripcionCorta() : "")
                                .build()
                        )
                        .build()
                )
                .setQuantity(Long.valueOf(item.getCantidad()))
                .build();
            
            lineItems.add(lineItem);
        }
        
        // Agregar envío como line item si es mayor a 0
        if (pedido.getEnvio() != null && pedido.getEnvio().compareTo(BigDecimal.ZERO) > 0) {
            SessionCreateParams.LineItem envioItem = SessionCreateParams.LineItem.builder()
                .setPriceData(
                    SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency("clp")
                        .setUnitAmount(convertirACentavos(pedido.getEnvio()))
                        .setProductData(
                            SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                .setName("Envío")
                                .build()
                        )
                        .build()
                )
                .setQuantity(1L)
                .build();
            
            lineItems.add(envioItem);
        }
        
        // Crear parámetros de la sesión con PayPal habilitado
        SessionCreateParams params = SessionCreateParams.builder()
            .setMode(SessionCreateParams.Mode.PAYMENT)
            .setSuccessUrl(frontendUrl + "/pago-exitoso?session_id={CHECKOUT_SESSION_ID}")
            .setCancelUrl(frontendUrl + "/carrito?canceled=true")
            .addAllLineItem(lineItems)
            .setClientReferenceId(pedido.getNumeroPedido())
            .putMetadata("pedido_id", String.valueOf(pedido.getId()))
            .putMetadata("usuario_id", String.valueOf(pedido.getUsuario().getId()))
            .setCustomerEmail(pedido.getUsuario().getEmail())
            .setShippingAddressCollection(
                SessionCreateParams.ShippingAddressCollection.builder()
                    .addAllowedCountry(SessionCreateParams.ShippingAddressCollection.AllowedCountry.CL)
                    .build()
            )
            // Habilitar PayPal como método de pago
            .addPaymentMethodType(SessionCreateParams.PaymentMethodType.CARD)
            .addPaymentMethodType(SessionCreateParams.PaymentMethodType.PAYPAL)
            .build();
        
        return Session.create(params);
    }
    
    /**
     * Convertir BigDecimal a centavos (long) para Stripe
     * Stripe maneja cantidades en centavos
     */
    private Long convertirACentavos(BigDecimal monto) {
        return monto.multiply(BigDecimal.valueOf(100)).longValue();
    }
    
    /**
     * Obtener sesión de pago por ID
     */
    public Session obtenerSesion(String sessionId) throws StripeException {
        return Session.retrieve(sessionId);
    }
    
    /**
     * Verificar si el pago fue exitoso
     */
    public boolean verificarPagoExitoso(String sessionId) throws StripeException {
        Session session = Session.retrieve(sessionId);
        return "paid".equals(session.getPaymentStatus());
    }
}
