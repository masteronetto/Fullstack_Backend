package com.danny.proyectokebumyspringbootbackend.controllers;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Account;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/diagnostico")
@CrossOrigin(origins = "*")
public class DiagnosticoController {
    
    @Value("${stripe.secret.key}")
    private String stripeSecretKey;
    
    /**
     * Verificar configuración de Stripe
     * GET /api/diagnostico/stripe
     */
    @GetMapping("/stripe")
    public ResponseEntity<?> verificarStripe() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Verificar que la key está configurada
            if (stripeSecretKey == null || stripeSecretKey.isEmpty()) {
                response.put("success", false);
                response.put("message", "Stripe API Key no configurada");
                response.put("key_prefix", "NO_KEY");
                return ResponseEntity.ok(response);
            }
            
            // Obtener prefijo de la key (primeros 15 caracteres)
            String keyPrefix = stripeSecretKey.substring(0, Math.min(15, stripeSecretKey.length())) + "...";
            response.put("key_prefix", keyPrefix);
            response.put("key_type", stripeSecretKey.startsWith("sk_test") ? "TEST" : "LIVE");
            
            // Intentar conectar con Stripe
            Stripe.apiKey = stripeSecretKey;
            Account account = Account.retrieve();
            
            response.put("success", true);
            response.put("message", "Conexión con Stripe exitosa");
            response.put("account_id", account.getId());
            response.put("account_email", account.getEmail());
            response.put("country", account.getCountry());
            
        } catch (StripeException e) {
            response.put("success", false);
            response.put("message", "Error al conectar con Stripe: " + e.getMessage());
            response.put("error_type", e.getClass().getSimpleName());
            response.put("error_code", e.getCode());
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error inesperado: " + e.getMessage());
        }
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Verificar estado general del backend
     * GET /api/diagnostico/salud
     */
    @GetMapping("/salud")
    public ResponseEntity<?> verificarSalud() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Backend funcionando correctamente");
        response.put("timestamp", System.currentTimeMillis());
        response.put("java_version", System.getProperty("java.version"));
        return ResponseEntity.ok(response);
    }
}
