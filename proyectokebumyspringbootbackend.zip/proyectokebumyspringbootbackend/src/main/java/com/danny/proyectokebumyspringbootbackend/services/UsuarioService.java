package com.danny.proyectokebumyspringbootbackend.services;

import java.util.List;

import com.danny.proyectokebumyspringbootbackend.entities.Usuario;

public interface UsuarioService {

    Usuario crear(Usuario usuario);
    Usuario obtenerId(Long id);
    List<Usuario> listarTodas();
    void eliminar(Long id);
    Usuario actualizar(Long id, Usuario usuarioActualizado);
    Usuario validarCredenciales(String email, String password);
}
