package com.danny.proyectokebumyspringbootbackend.repositories;

import com.danny.proyectokebumyspringbootbackend.entities.Carrito;
import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    Optional<Carrito> findByUsuarioAndEstado(Usuario usuario, String estado);
    Optional<Carrito> findByUsuario_IdAndEstado(Long usuarioId, String estado);
}
