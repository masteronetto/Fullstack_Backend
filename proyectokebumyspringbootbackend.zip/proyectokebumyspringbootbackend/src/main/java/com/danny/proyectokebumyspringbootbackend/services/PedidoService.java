package com.danny.proyectokebumyspringbootbackend.services;

import com.danny.proyectokebumyspringbootbackend.entities.*;
import com.danny.proyectokebumyspringbootbackend.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class PedidoService {
    
    @Autowired
    private PedidoRepository pedidoRepository;
    
    @Autowired
    private CarritoService carritoService;
    
    @Autowired
    private CarritoRepository carritoRepository;
    
    @Autowired
    private ProductoRepository productoRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    /**
     * Crear pedido simulado sin Stripe
     */
    @Transactional
    public Pedido crearPedidoSimulado(Long usuarioId, DatosEnvioDTO datosEnvio) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        
        Carrito carrito = carritoService.obtenerCarritoActivo(usuarioId);
        
        if (carrito.getItems().isEmpty()) {
            throw new RuntimeException("El carrito está vacío");
        }
        
        // Validar stock de todos los productos
        for (ItemCarrito itemCarrito : carrito.getItems()) {
            Producto producto = itemCarrito.getProducto();
            if (producto.getStock() < itemCarrito.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para " + producto.getNombre() + 
                    ". Disponible: " + producto.getStock());
            }
        }
        
        // Crear el pedido
        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setEstadoPedido("pendiente_pago"); // Esperando pago
        pedido.setEstadoPago("pendiente");
        pedido.setMetodoPago("pendiente");
        
        // Generar número de pedido
        pedido.setNumeroPedido(generarNumeroPedido());
        
        // Datos de envío
        pedido.setDireccionEnvio(datosEnvio.getDireccion());
        pedido.setCiudad(datosEnvio.getCiudad());
        pedido.setRegion(datosEnvio.getRegion());
        pedido.setCodigoPostal(datosEnvio.getCodigoPostal());
        pedido.setTelefonoContacto(datosEnvio.getTelefono());
        pedido.setNotas(datosEnvio.getNotas());
        
        // Calcular totales
        BigDecimal subtotal = BigDecimal.ZERO;
        
        // Copiar items del carrito al pedido
        for (ItemCarrito itemCarrito : carrito.getItems()) {
            ItemPedido itemPedido = new ItemPedido();
            itemPedido.setPedido(pedido);
            itemPedido.setProducto(itemCarrito.getProducto());
            itemPedido.setNombreProducto(itemCarrito.getProducto().getNombre());
            itemPedido.setCantidad(itemCarrito.getCantidad());
            itemPedido.setPrecioUnitario(itemCarrito.getPrecioUnitario());
            pedido.getItems().add(itemPedido);
            
            subtotal = subtotal.add(itemCarrito.getSubtotal());
        }
        
        pedido.setSubtotal(subtotal);
        
        // Calcular IVA (19% sobre subtotal, con dos decimales)
        BigDecimal iva = subtotal.multiply(new BigDecimal("0.19")).setScale(2, java.math.RoundingMode.HALF_UP);
        pedido.setIva(iva);

        // Calcular envío (gratis sobre $50.000)
        BigDecimal envio = subtotal.compareTo(new BigDecimal("50000")) >= 0 
            ? BigDecimal.ZERO 
            : new BigDecimal("3000");
        pedido.setEnvio(envio);
        
        // Total (subtotal + iva + envio)
        BigDecimal total = subtotal.add(iva).add(envio);
        pedido.setTotal(total);
        
        // Guardar pedido
        return pedidoRepository.save(pedido);
    }
    
    /**
     * Procesar pago simulado
     */
    @Transactional
    public Pedido procesarPagoSimulado(Long pedidoId, String metodoPago) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        
        if (!"pendiente_pago".equals(pedido.getEstadoPedido())) {
            throw new RuntimeException("El pedido ya fue procesado");
        }
        
        // Validar stock nuevamente antes de confirmar
        for (ItemPedido item : pedido.getItems()) {
            Producto producto = item.getProducto();
            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para " + producto.getNombre());
            }
        }
        
        // Reducir stock de los productos
        for (ItemPedido item : pedido.getItems()) {
            Producto producto = item.getProducto();
            producto.setStock(producto.getStock() - item.getCantidad());
            productoRepository.save(producto);
        }
        
        // Actualizar estado del pedido
        pedido.setEstadoPago("pagado");
        pedido.setEstadoPedido("pendiente"); // Pendiente de confirmación del admin
        pedido.setMetodoPago(metodoPago);
        pedido.setFechaPago(LocalDateTime.now());
        
        // Limpiar el carrito del usuario
        Carrito carrito = carritoRepository.findByUsuario_IdAndEstado(
            pedido.getUsuario().getId(), "activo"
        ).orElse(null);
        
        if (carrito != null) {
            carrito.getItems().clear();
            carrito.setEstado("convertido");
            carritoRepository.save(carrito);
        }
        
        return pedidoRepository.save(pedido);
    }
    
    /**
     * Obtener pedido por ID
     */
    public Pedido obtenerPedidoPorId(Long pedidoId) {
        return pedidoRepository.findById(pedidoId)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }
    
    /**
     * Obtener pedido por número
     */
    public Pedido obtenerPedidoPorNumero(String numeroPedido) {
        return pedidoRepository.findByNumeroPedido(numeroPedido)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }
    
    /**
     * Obtener pedidos de un usuario
     */
    public List<Pedido> obtenerPedidosUsuario(Long usuarioId) {
        return pedidoRepository.findByUsuarioIdOrderByFechaPedidoDesc(usuarioId);
    }
    
    /**
     * Obtener todos los pedidos
     */
    public List<Pedido> obtenerTodosPedidos() {
        return pedidoRepository.findAllByOrderByFechaPedidoDesc();
    }
    
    /**
     * Obtener pedidos por estado
     */
    public List<Pedido> obtenerPedidosPorEstado(String estado) {
        return pedidoRepository.findByEstadoPedidoOrderByFechaPedidoDesc(estado);
    }
    
    /**
     * Actualizar estado del pedido
     */
    @Transactional
    public Pedido actualizarEstadoPedido(Long pedidoId, String nuevoEstado) {
        Pedido pedido = obtenerPedidoPorId(pedidoId);
        pedido.setEstadoPedido(nuevoEstado);
        return pedidoRepository.save(pedido);
    }
    
    /**
     * Generar número de pedido único
     */
    private String generarNumeroPedido() {
        LocalDateTime now = LocalDateTime.now();
        String fecha = now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        long count = pedidoRepository.count() + 1;
        return String.format("PED-%s-%04d", fecha, count);
    }
    
    // DTOs
    public static class DatosEnvioDTO {
        private String direccion;
        private String ciudad;
        private String region;
        private String codigoPostal;
        private String telefono;
        private String notas;
        
        public String getDireccion() { return direccion; }
        public void setDireccion(String direccion) { this.direccion = direccion; }
        public String getCiudad() { return ciudad; }
        public void setCiudad(String ciudad) { this.ciudad = ciudad; }
        public String getRegion() { return region; }
        public void setRegion(String region) { this.region = region; }
        public String getCodigoPostal() { return codigoPostal; }
        public void setCodigoPostal(String codigoPostal) { this.codigoPostal = codigoPostal; }
        public String getTelefono() { return telefono; }
        public void setTelefono(String telefono) { this.telefono = telefono; }
        public String getNotas() { return notas; }
        public void setNotas(String notas) { this.notas = notas; }
    }
}
