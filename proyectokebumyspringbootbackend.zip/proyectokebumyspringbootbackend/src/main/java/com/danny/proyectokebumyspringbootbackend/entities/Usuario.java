package com.danny.proyectokebumyspringbootbackend.entities;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Column;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;

@Entity
@Data
public class Usuario {
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario") // Compatibilidad con BDD
    private Long id; 

    private String nombre;
    private String email;
    private String password;
    
    @Column(name = "tipo_usuario") // Campo requerido por frontend BDD
    private String tipoUsuario = "usuario"; // 'usuario' o 'administrador'
    
    private String rol = "cliente"; // Mantener para compatibilidad
    private String estado = "activo"; 
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;
    
    @PrePersist
    protected void onCreate() {
        fechaCreacion = LocalDateTime.now();
    }
}
