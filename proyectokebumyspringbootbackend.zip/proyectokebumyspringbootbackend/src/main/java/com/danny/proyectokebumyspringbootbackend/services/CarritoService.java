package com.danny.proyectokebumyspringbootbackend.services;

import com.danny.proyectokebumyspringbootbackend.entities.*;
import com.danny.proyectokebumyspringbootbackend.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class CarritoService {
    
    @Autowired
    private CarritoRepository carritoRepository;
    
    @Autowired
    private ProductoRepository productoRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    /**
     * Obtener o crear carrito activo para un usuario
     */
    @Transactional
    public Carrito obtenerCarritoActivo(Long usuarioId) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        
        return carritoRepository.findByUsuario_IdAndEstado(usuarioId, "activo")
            .orElseGet(() -> {
                Carrito nuevoCarrito = new Carrito();
                nuevoCarrito.setUsuario(usuario);
                nuevoCarrito.setEstado("activo");
                return carritoRepository.save(nuevoCarrito);
            });
    }
    
    /**
     * Agregar producto al carrito
     */
    @Transactional
    public Carrito agregarProducto(Long usuarioId, Long productoId, Integer cantidad) {
        Carrito carrito = obtenerCarritoActivo(usuarioId);
        Producto producto = productoRepository.findById(productoId)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        
        // Validar stock
        if (producto.getStock() < cantidad) {
            throw new RuntimeException("Stock insuficiente. Disponible: " + producto.getStock());
        }
        
        // Buscar si el producto ya existe en el carrito
        Optional<ItemCarrito> itemExistente = carrito.getItems().stream()
            .filter(item -> item.getProducto().getId().equals(productoId))
            .findFirst();
        
        if (itemExistente.isPresent()) {
            // Actualizar cantidad
            ItemCarrito item = itemExistente.get();
            int nuevaCantidad = item.getCantidad() + cantidad;
            
            if (producto.getStock() < nuevaCantidad) {
                throw new RuntimeException("Stock insuficiente. Disponible: " + producto.getStock());
            }
            
            item.setCantidad(nuevaCantidad);
        } else {
            // Crear nuevo item
            ItemCarrito nuevoItem = new ItemCarrito();
            nuevoItem.setCarrito(carrito);
            nuevoItem.setProducto(producto);
            nuevoItem.setCantidad(cantidad);
            nuevoItem.setPrecioUnitario(producto.getPrecio());
            carrito.getItems().add(nuevoItem);
        }
        
        return carritoRepository.save(carrito);
    }
    
    /**
     * Actualizar cantidad de un item del carrito
     */
    @Transactional
    public Carrito actualizarCantidad(Long usuarioId, Long productoId, Integer nuevaCantidad) {
        Carrito carrito = obtenerCarritoActivo(usuarioId);
        
        if (nuevaCantidad <= 0) {
            return eliminarProducto(usuarioId, productoId);
        }
        
        ItemCarrito item = carrito.getItems().stream()
            .filter(i -> i.getProducto().getId().equals(productoId))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Producto no encontrado en el carrito"));
        
        // Validar stock
        if (item.getProducto().getStock() < nuevaCantidad) {
            throw new RuntimeException("Stock insuficiente. Disponible: " + item.getProducto().getStock());
        }
        
        item.setCantidad(nuevaCantidad);
        return carritoRepository.save(carrito);
    }
    
    /**
     * Eliminar producto del carrito
     */
    @Transactional
    public Carrito eliminarProducto(Long usuarioId, Long productoId) {
        Carrito carrito = obtenerCarritoActivo(usuarioId);
        carrito.getItems().removeIf(item -> item.getProducto().getId().equals(productoId));
        return carritoRepository.save(carrito);
    }
    
    /**
     * Limpiar todo el carrito
     */
    @Transactional
    public void limpiarCarrito(Long usuarioId) {
        Carrito carrito = obtenerCarritoActivo(usuarioId);
        carrito.getItems().clear();
        carritoRepository.save(carrito);
    }
    
    /**
     * Calcular total del carrito
     */
    public BigDecimal calcularTotal(Carrito carrito) {
        return carrito.getItems().stream()
            .map(ItemCarrito::getSubtotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    /**
     * Sincronizar carrito del frontend con el backend
     */
    @Transactional
    public Carrito sincronizarCarrito(Long usuarioId, List<ItemCarritoDTO> itemsDTO) {
        Carrito carrito = obtenerCarritoActivo(usuarioId);
        carrito.getItems().clear(); // Limpiar items existentes
        
        for (ItemCarritoDTO itemDTO : itemsDTO) {
            Producto producto = productoRepository.findById(itemDTO.getProductoId())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado: " + itemDTO.getProductoId()));
            
            // Validar stock
            if (producto.getStock() < itemDTO.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para " + producto.getNombre() + 
                    ". Disponible: " + producto.getStock());
            }
            
            ItemCarrito item = new ItemCarrito();
            item.setCarrito(carrito);
            item.setProducto(producto);
            item.setCantidad(itemDTO.getCantidad());
            item.setPrecioUnitario(producto.getPrecio());
            carrito.getItems().add(item);
        }
        
        return carritoRepository.save(carrito);
    }
    
    // DTO para sincronización
    public static class ItemCarritoDTO {
        private Long productoId;
        private Integer cantidad;
        
        public Long getProductoId() { return productoId; }
        public void setProductoId(Long productoId) { this.productoId = productoId; }
        public Integer getCantidad() { return cantidad; }
        public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
    }
}
