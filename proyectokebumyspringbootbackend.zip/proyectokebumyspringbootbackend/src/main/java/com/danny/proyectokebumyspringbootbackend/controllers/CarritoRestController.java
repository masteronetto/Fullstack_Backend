package com.danny.proyectokebumyspringbootbackend.controllers;

import com.danny.proyectokebumyspringbootbackend.entities.Carrito;
import com.danny.proyectokebumyspringbootbackend.services.CarritoService;
import com.danny.proyectokebumyspringbootbackend.services.CarritoService.ItemCarritoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/carrito")
@CrossOrigin(origins = "*")
public class CarritoRestController {
    
    @Autowired
    private CarritoService carritoService;
    
    /**
     * Obtener carrito activo del usuario
     * GET /api/carrito/{usuarioId}
     */
    @GetMapping("/{usuarioId}")
    public ResponseEntity<?> obtenerCarrito(@PathVariable Long usuarioId) {
        try {
            Carrito carrito = carritoService.obtenerCarritoActivo(usuarioId);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("carrito", carrito);
            response.put("total", carritoService.calcularTotal(carrito));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Agregar producto al carrito
     * POST /api/carrito/{usuarioId}/agregar
     */
    @PostMapping("/{usuarioId}/agregar")
    public ResponseEntity<?> agregarProducto(
            @PathVariable Long usuarioId,
            @RequestBody Map<String, Object> request) {
        try {
            Long productoId = Long.valueOf(request.get("productoId").toString());
            Integer cantidad = Integer.valueOf(request.get("cantidad").toString());
            
            Carrito carrito = carritoService.agregarProducto(usuarioId, productoId, cantidad);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Producto agregado al carrito",
                "carrito", carrito,
                "total", carritoService.calcularTotal(carrito)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Actualizar cantidad de un producto
     * PUT /api/carrito/{usuarioId}/actualizar
     */
    @PutMapping("/{usuarioId}/actualizar")
    public ResponseEntity<?> actualizarCantidad(
            @PathVariable Long usuarioId,
            @RequestBody Map<String, Object> request) {
        try {
            Long productoId = Long.valueOf(request.get("productoId").toString());
            Integer cantidad = Integer.valueOf(request.get("cantidad").toString());
            
            Carrito carrito = carritoService.actualizarCantidad(usuarioId, productoId, cantidad);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Cantidad actualizada",
                "carrito", carrito,
                "total", carritoService.calcularTotal(carrito)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Eliminar producto del carrito
     * DELETE /api/carrito/{usuarioId}/eliminar/{productoId}
     */
    @DeleteMapping("/{usuarioId}/eliminar/{productoId}")
    public ResponseEntity<?> eliminarProducto(
            @PathVariable Long usuarioId,
            @PathVariable Long productoId) {
        try {
            Carrito carrito = carritoService.eliminarProducto(usuarioId, productoId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Producto eliminado del carrito",
                "carrito", carrito,
                "total", carritoService.calcularTotal(carrito)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Limpiar todo el carrito
     * DELETE /api/carrito/{usuarioId}/limpiar
     */
    @DeleteMapping("/{usuarioId}/limpiar")
    public ResponseEntity<?> limpiarCarrito(@PathVariable Long usuarioId) {
        try {
            carritoService.limpiarCarrito(usuarioId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Carrito limpiado"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    /**
     * Sincronizar carrito del frontend con backend
     * POST /api/carrito/{usuarioId}/sincronizar
     */
    @PostMapping("/{usuarioId}/sincronizar")
    public ResponseEntity<?> sincronizarCarrito(
            @PathVariable Long usuarioId,
            @RequestBody Map<String, List<ItemCarritoDTO>> request) {
        try {
            List<ItemCarritoDTO> items = request.get("items");
            Carrito carrito = carritoService.sincronizarCarrito(usuarioId, items);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Carrito sincronizado",
                "carrito", carrito,
                "total", carritoService.calcularTotal(carrito)
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}
