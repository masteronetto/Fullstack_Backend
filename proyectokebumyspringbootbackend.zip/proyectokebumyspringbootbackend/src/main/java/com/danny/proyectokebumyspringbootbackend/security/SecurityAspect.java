package com.danny.proyectokebumyspringbootbackend.security;

import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.HashMap;
import java.util.Map;

/**
 * Aspecto para validar autenticación y autorización usando las anotaciones
 */
@Aspect
@Component
public class SecurityAspect {

    @Around("@annotation(requiresAuth)")
    public Object checkAuthentication(ProceedingJoinPoint joinPoint, RequiresAuth requiresAuth) throws Throwable {
        HttpServletRequest request = getCurrentRequest();
        
        if (request == null) {
            return createUnauthorizedResponse("No se pudo obtener el contexto de la petición");
        }

        // Verificar si hay un usuario autenticado
        Long userId = (Long) request.getAttribute("userId");
        String tokenError = (String) request.getAttribute("tokenError");

        if (userId == null || tokenError != null) {
            return createUnauthorizedResponse("Debe iniciar sesión para acceder a este recurso");
        }

        // Usuario autenticado, continuar
        return joinPoint.proceed();
    }

    @Around("@annotation(requiresAdmin)")
    public Object checkAdminRole(ProceedingJoinPoint joinPoint, RequiresAdmin requiresAdmin) throws Throwable {
        HttpServletRequest request = getCurrentRequest();
        
        if (request == null) {
            return createUnauthorizedResponse("No se pudo obtener el contexto de la petición");
        }

        // Verificar si hay un usuario autenticado
        Long userId = (Long) request.getAttribute("userId");
        String rol = (String) request.getAttribute("userRol");
        String tokenError = (String) request.getAttribute("tokenError");

        if (userId == null || tokenError != null) {
            return createUnauthorizedResponse("Debe iniciar sesión para acceder a este recurso");
        }

        // Verificar si el usuario es administrador
        if (!"admin".equals(rol)) {
            return createForbiddenResponse("No tiene permisos de administrador para acceder a este recurso");
        }

        // Usuario es admin, continuar
        return joinPoint.proceed();
    }

    private HttpServletRequest getCurrentRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return attributes != null ? attributes.getRequest() : null;
    }

    private ResponseEntity<?> createUnauthorizedResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        response.put("error", "UNAUTHORIZED");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
    }

    private ResponseEntity<?> createForbiddenResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        response.put("error", "FORBIDDEN");
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
    }
}
