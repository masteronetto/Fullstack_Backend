package com.danny.proyectokebumyspringbootbackend.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

/**
 * Filtro para interceptar y validar tokens JWT en cada petición
 * Flujo: Peticiones → Validación → Acceso
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtService jwtService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        
        // Obtener el token del header Authorization
        String authHeader = request.getHeader("Authorization");
        String token = null;
        String email = null;

        // Extraer el token si existe
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            try {
                email = jwtService.extractEmail(token);
                System.out.println("📧 Token recibido para email: " + email);
            } catch (Exception e) {
                System.out.println("❌ Error al extraer email del token: " + e.getMessage());
            }
        }

        // Si hay token, validarlo y establecer autenticación en Spring Security
        if (token != null && email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            try {
                if (jwtService.validateToken(token, email)) {
                    String rol = jwtService.extractRol(token);
                    String tipoUsuario = jwtService.extractTipoUsuario(token);
                    Long userId = jwtService.extractUserId(token);
                    
                    // Agregar información del usuario al request para uso posterior
                    request.setAttribute("userId", userId);
                    request.setAttribute("userEmail", email);
                    request.setAttribute("userRol", rol);
                    request.setAttribute("userTipoUsuario", tipoUsuario);
                    
                    // Crear autenticación para Spring Security
                    // El rol debe tener prefijo ROLE_ para Spring Security
                    String authority = "ROLE_" + rol.toUpperCase();
                    SimpleGrantedAuthority grantedAuthority = new SimpleGrantedAuthority(authority);
                    
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                        email,
                        null,
                        Collections.singletonList(grantedAuthority)
                    );
                    
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    
                    System.out.println("✅ Token válido - User: " + email + " | Rol: " + rol + " | Authority: " + authority);
                } else {
                    System.out.println("⚠️ Token inválido o expirado");
                    request.setAttribute("tokenError", "Token inválido o expirado");
                }
            } catch (Exception e) {
                System.out.println("❌ Error al validar token: " + e.getMessage());
                request.setAttribute("tokenError", "Error al validar token");
            }
        }

        // Continuar con la cadena de filtros
        filterChain.doFilter(request, response);
    }
}
