package com.danny.proyectokebumyspringbootbackend.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Column;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
public class Producto {
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto") // Compatibilidad con BDD
    private Long id; 
    
    private String nombre;
    private String descripcion;
    
    @Column(name = "descripcion_corta") // Campo requerido por frontend BDD
    private String descripcionCorta;
    
    private BigDecimal precio; 
    private int stock;
    
    @Column(name = "stock_disponible") // Alias para compatibilidad
    private Integer stockDisponible;
    
    @Column(name = "stock_minimo") // Campo adicional del BDD
    private Integer stockMinimo = 10;
    
    private String estado = "activo";
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;
    
    @Column(name = "categoria") // Simplificar nombre para BDD
    private String categoria; 
    
    @Column(name = "imagen_principal") // Nombre usado en BDD
    private String imagenPrincipal;
    
    @Column(name = "personalizable") // Campo requerido por BDD
    private String personalizable = "No"; // 'Sí' o 'No'
    
    // Mantener campos originales para compatibilidad
    @Column(name = "categoria_nombre")
    private String categoriaNombre; 
    
    @Column(name = "imagen_url")
    private String imagenUrl; 
    
    @PrePersist
    protected void onCreate() {
        fechaCreacion = LocalDateTime.now();
    }
}
