package com.danny.proyectokebumyspringbootbackend.security;

import com.danny.proyectokebumyspringbootbackend.entities.Usuario;
import com.danny.proyectokebumyspringbootbackend.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * Servicio personalizado para cargar usuarios desde la base de datos
 * Requerido por Spring Security para autenticación
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Buscar usuario por email
        Usuario usuario = usuarioRepository.findByEmail(email);
        
        if (usuario == null) {
            throw new UsernameNotFoundException("Usuario no encontrado con email: " + email);
        }

        // Crear authority con prefijo ROLE_
        String authority = "ROLE_" + usuario.getRol().toUpperCase();
        
        return User.builder()
                .username(usuario.getEmail())
                .password(usuario.getPassword())
                .authorities(Collections.singletonList(new SimpleGrantedAuthority(authority)))
                .accountExpired(false)
                .accountLocked(!"activo".equalsIgnoreCase(usuario.getEstado()))
                .credentialsExpired(false)
                .disabled(!"activo".equalsIgnoreCase(usuario.getEstado()))
                .build();
    }
}
